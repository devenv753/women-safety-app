<?php
    include 'db_connect.php';
    $user_id = $_GET['user_id'];
    $sql = "SELECT * FROM Emergency_Contacts WHERE user_id = '$user_id'";
    $result = $conn->query($sql);
    $contacts = array();
    while($row = $result->fetch_assoc()) {
        $contacts[] = $row;
    }
    echo json_encode($contacts);
    $conn->close();
?>
