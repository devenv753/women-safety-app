<?php
    include 'db_connect.php';

    // Set JSON header (optional but good for API)
    header('Content-Type: application/json');

    // Check DB connection
    if ($conn->connect_error) {
        echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
        exit;
    }

    // Get POST data safely
    $user_id   = isset($_POST['user_id']) ? trim($_POST['user_id']) : '';
    $latitude  = isset($_POST['latitude']) ? trim($_POST['latitude']) : '';
    $longitude = isset($_POST['longitude']) ? trim($_POST['longitude']) : '';

    // Validate required fields
    if ($user_id === '' || $latitude === '' || $longitude === '') {
        echo json_encode(["status" => "error", "message" => "Missing user_id, latitude or longitude."]);
        exit;
    }

    // Cast values safely
    $user_id = (int)$user_id;
    $latitude = (float)$latitude;
    $longitude = (float)$longitude;

    // Insert using prepared statement
    $stmt = $conn->prepare("INSERT INTO Location_History (user_id, latitude, longitude, timestamp) VALUES (?, ?, ?, NOW())");

    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Failed to prepare statement: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("idd", $user_id, $latitude, $longitude);

    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "Location added successfully.",
            "data" => [
                "user_id" => $user_id,
                "latitude" => $latitude,
                "longitude" => $longitude
            ]
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Insert failed: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
?>
