<?php
    include 'db_connect.php';
    $user_id = $_GET['user_id'];
    $sql = "SELECT * FROM Location_History WHERE user_id = '$user_id' ORDER BY timestamp DESC";
    $result = $conn->query($sql);
    $locations = array();
    while($row = $result->fetch_assoc()) {
        $locations[] = $row;
    }
    echo json_encode($locations);
    $conn->close();
?>
