<?php
    include 'db_connect.php';  // যেখানে $conn ডাটাবেস কানেকশন করা আছে

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        echo "Database connected successfully";
    }
?>
