<?php
    include 'db_connect.php';

    // Set content type to JSON
    header('Content-Type: application/json');

    // Check DB connection
    if ($conn->connect_error) {
        echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
        exit;
    }

    // Get and sanitize input
    $user_id = isset($_POST['user_id']) ? trim($_POST['user_id']) : '';
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';

    // Basic validation
    if ($user_id === '' || $name === '' || $phone === '') {
        echo json_encode(["status" => "error", "message" => "Please provide user_id, name, and phone."]);
        exit;
    }

    // Convert user_id to integer
    $user_id = (int)$user_id;

    // Prepare insert statement
    $stmt = $conn->prepare("INSERT INTO emergency_contacts (user_id, name, phone) VALUES (?, ?, ?)");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Prepare failed: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("iss", $user_id, $name, $phone);

    // Execute and respond
    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "Contact added successfully.",
            "data" => [
                "user_id" => $user_id,
                "name" => $name,
                "phone" => $phone
            ]
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Insert failed: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
?>
