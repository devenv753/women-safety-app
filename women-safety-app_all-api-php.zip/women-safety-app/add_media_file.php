<?php
    include 'db_connect.php';

    // Set JSON response header
    header('Content-Type: application/json');

    // Check database connection
    if ($conn->connect_error) {
        echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
        exit;
    }

    // Retrieve and sanitize POST data
    $event_id   = isset($_POST['event_id']) ? trim($_POST['event_id']) : '';
    $media_type = isset($_POST['media_type']) ? trim($_POST['media_type']) : '';
    $file_path  = isset($_POST['file_path']) ? trim($_POST['file_path']) : '';

    // Validate input
    if ($event_id === '' || $media_type === '' || $file_path === '') {
        echo json_encode(["status" => "error", "message" => "Missing event_id, media_type, or file_path."]);
        exit;
    }

    $event_id = (int)$event_id;

    // Prepare insert statement
    $stmt = $conn->prepare("INSERT INTO Media_Files (event_id, media_type, file_path) VALUES (?, ?, ?)");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Prepare failed: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("iss", $event_id, $media_type, $file_path);

    // Execute and respond
    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "Media file record added successfully.",
            "data" => [
                "media_id" => $stmt->insert_id,
                "event_id" => $event_id,
                "media_type" => $media_type,
                "file_path" => $file_path
            ]
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Insert failed: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
?>
