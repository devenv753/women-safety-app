<?php
    include 'db_connect.php';

    // Set content type to JSON
    header('Content-Type: application/json');

    // Check DB connection
    if ($conn->connect_error) {
        echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
        exit;
    }

    // Get and sanitize input
    $name     = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email    = isset($_POST['email']) ? trim($_POST['email']) : '';
    $phone    = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    // Validate required fields
    if ($name === '' || $email === '' || $phone === '' || $password === '') {
        echo json_encode(["status" => "error", "message" => "Missing required fields: name, email, phone, or password."]);
        exit;
    }

    // Optionally: hash password for security
    // $password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare statement
    $stmt = $conn->prepare("INSERT INTO Users (name, email, phone, password) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Failed to prepare statement: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("ssss", $name, $email, $phone, $password);

    // Execute and send response
    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "User registered successfully.",
            "data" => [
                "user_id" => $stmt->insert_id,
                "name" => $name,
                "email" => $email,
                "phone" => $phone
            ]
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Insert failed: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
?>
