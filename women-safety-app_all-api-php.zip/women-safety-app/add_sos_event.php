<?php
    include 'db_connect.php';

    // Set JSON header
    header('Content-Type: application/json');

    // Check DB connection
    if ($conn->connect_error) {
        echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
        exit;
    }

    // Get POST data
    $user_id  = isset($_POST['user_id']) ? trim($_POST['user_id']) : '';
    $location = isset($_POST['location']) ? trim($_POST['location']) : '';
    $status   = isset($_POST['status']) ? trim($_POST['status']) : '';

    // Validate input
    if ($user_id === '' || $location === '' || $status === '') {
        echo json_encode(["status" => "error", "message" => "Missing user_id, location, or status."]);
        exit;
    }

    $user_id = (int)$user_id;

    // Prepare and execute insert
    $stmt = $conn->prepare("INSERT INTO SOS_Events (user_id, timestamp, location, status) VALUES (?, NOW(), ?, ?)");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Prepare failed: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("iss", $user_id, $location, $status);

    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "SOS event recorded successfully.",
            "data" => [
                "event_id" => $stmt->insert_id,
                "user_id" => $user_id,
                "location" => $location,
                "status" => $status
            ]
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Insert failed: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
?>
